#pragma once

#include "Window.h"
#include "Draw_tools.h"

using namespace Draw_lib;

class Mywindow : public Window
{
public:
	Mywindow(int w, int h, const std::string& title)
		: Window(w, h, title)
	{
		static Circle circle{ Point{50,50}, 50 }; // object on constructor must be static
		circle.set_color(Color::black);
		attach(circle);
	}
};

int main()
{
	Mywindow mywindow(600, 600, "My Window");
	Draw_lib::Rectangle rectangle{ Point{200, 200}, 100, 40 };
	rectangle.set_color(Color::blue);
	rectangle.set_fill_color(Color::yellow);
	mywindow.attach(rectangle);

	Draw_lib::gui_main();
}